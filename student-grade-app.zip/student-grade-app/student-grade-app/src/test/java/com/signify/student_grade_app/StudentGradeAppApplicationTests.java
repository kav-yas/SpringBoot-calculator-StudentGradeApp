package com.signify.student_grade_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentGradeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
